// ═══════════════════════════════════════════════════════════════
//  security.js  —  WebRTC Signaling Server Security Module
//
//  Drop-in protection layer for server.js. Zero changes to
//  existing working code — mount middleware and call guards.
//
//  ┌──────────────────────────────────────────────────────┐
//  │  USAGE IN server.js                                  │
//  │                                                      │
//  │  const security = require("./security");             │
//  │                                                      │
//  │  // After app / io are created, before routes:       │
//  │  security.applyHttpMiddleware(app);                  │
//  │                                                      │
//  │  // Replace /api/ice-config handler:                 │
//  │  app.get("/api/ice-config",                          │
//  │    security.iceConfigMiddleware, iceConfigHandler);  │
//  │                                                      │
//  │  // In io.on("connection", socket => { ... }):       │
//  │  if (!security.allowConnection(socket)) return;      │
//  │                                                      │
//  │  // In socket.on("join-room", ...):                  │
//  │  if (!security.allowJoin(socket, roomId)) return;   │
//  │                                                      │
//  │  // In webrtc-offer / webrtc-answer / webrtc-ice:   │
//  │  if (!security.allowSignal(socket)) return;          │
//  └──────────────────────────────────────────────────────┘
// ═══════════════════════════════════════════════════════════════

"use strict";

// ── Tuneable constants ────────────────────────────────────────
// Adjust via environment variables or edit here.
const CFG = {
  // HTTP rate limiting
  HTTP_WINDOW_MS:   60_000,          // 1-minute sliding window
  HTTP_MAX:         parseInt(process.env.SEC_HTTP_MAX)        || 300,

  // Socket connection rate limiting (per IP per minute)
  CONN_WINDOW_MS:   60_000,
  CONN_MAX:         parseInt(process.env.SEC_CONN_MAX)        || 20,

  // Room join brute-force protection (per IP per minute)
  JOIN_WINDOW_MS:   60_000,
  JOIN_MAX:         parseInt(process.env.SEC_JOIN_MAX)        || 30,

  // Signaling spam protection (per socket per minute)
  SIGNAL_WINDOW_MS: 60_000,
  SIGNAL_MAX:       parseInt(process.env.SEC_SIGNAL_MAX)      || 100,

  // Block duration after limit exceeded (ms)
  BLOCK_HTTP_MS:    parseInt(process.env.SEC_BLOCK_HTTP_MS)   || 20_000,
  BLOCK_CONN_MS:    parseInt(process.env.SEC_BLOCK_CONN_MS)   || 60_000,
  BLOCK_JOIN_MS:    parseInt(process.env.SEC_BLOCK_JOIN_MS)   || 120_000,
  BLOCK_SIGNAL_MS:  parseInt(process.env.SEC_BLOCK_SIGNAL_MS) || 60_000,

  // Room ID validation
  ROOM_ID_MIN:      parseInt(process.env.SEC_ROOM_ID_MIN)     || 6,
  ROOM_ID_MAX:      parseInt(process.env.SEC_ROOM_ID_MAX)     || 32,
  ROOM_ID_REGEX:    /^[a-zA-Z0-9_-]+$/,

  // TURN credential TTL (ms) — 10 minutes default
  TURN_TTL_MS:      parseInt(process.env.SEC_TURN_TTL_MS)     || 600_000,

  // Trust proxy headers (set true if behind nginx / Cloudflare)
  TRUST_PROXY:      process.env.SEC_TRUST_PROXY === "true" || false,
};

// ─────────────────────────────────────────────────────────────
//  SECTION 1 — SECURITY LOGGER
// ─────────────────────────────────────────────────────────────

const EventType = Object.freeze({
  HTTP_RATE_LIMIT:    "HTTP_RATE_LIMIT",
  CONN_RATE_LIMIT:    "CONN_RATE_LIMIT",
  JOIN_BRUTE_FORCE:   "JOIN_BRUTE_FORCE",
  SIGNAL_SPAM:        "SIGNAL_SPAM",
  INVALID_ROOM_ID:    "INVALID_ROOM_ID",
  ROOM_FULL:          "ROOM_FULL",
  TURN_ISSUED:        "TURN_ISSUED",
  TURN_EXPIRED:       "TURN_EXPIRED",
  TURN_REJECTED:      "TURN_REJECTED",
});

/**
 * secLog(eventType, ip, details)
 *
 * Writes a structured one-line security log entry to stdout.
 * Format: [SEC] 2025-01-01T00:00:00.000Z  IP  EVENT_TYPE  details
 *
 * Intentionally does NOT write to disk to avoid file-write
 * overhead on the hot path. Pipe stdout to a file or log
 * aggregator (PM2 logs, journald, Datadog) externally.
 */
function secLog(eventType, ip, details) {
  const ts = new Date().toISOString();
  const safeIp = String(ip || "unknown").slice(0, 45);
  const safeDetails = typeof details === "object"
    ? JSON.stringify(details)
    : String(details || "");
  console.warn(`[SEC] ${ts}  ${safeIp}  ${eventType}  ${safeDetails}`);
}

// ─────────────────────────────────────────────────────────────
//  SECTION 2 — IP EXTRACTION
// ─────────────────────────────────────────────────────────────

/**
 * getIp(req) → string
 *
 * Returns the best-effort real client IP.
 * When TRUST_PROXY=true, reads x-forwarded-for first.
 * Falls back to socket remoteAddress (IPv4 or IPv4-mapped IPv6).
 */
function getIp(reqOrSocket) {
  let raw = "";

  if (CFG.TRUST_PROXY) {
    const xfwd =
      (reqOrSocket.headers?.["x-forwarded-for"]) ||
      (reqOrSocket.handshake?.headers?.["x-forwarded-for"]) || "";
    if (xfwd) {
      // x-forwarded-for may be comma-separated: "client, proxy1, proxy2"
      raw = xfwd.split(",")[0].trim();
    }
  }

  if (!raw) {
    raw =
      reqOrSocket.ip ||
      reqOrSocket.remoteAddress ||
      reqOrSocket.handshake?.address ||
      "";
  }

  // Strip IPv6-mapped IPv4 prefix: "::ffff:1.2.3.4" → "1.2.3.4"
  return raw.replace(/^::ffff:/, "");
}

// ─────────────────────────────────────────────────────────────
//  SECTION 3 — GENERIC SLIDING-WINDOW RATE LIMITER
// ─────────────────────────────────────────────────────────────

/**
 * RateLimiter
 *
 * A memory-efficient sliding-window counter keyed by arbitrary
 * string (IP, socket ID, etc.).  Uses a simple array of timestamps
 * rather than Redis so it works in single-process deployments.
 * For multi-process, swap the _store Map for a shared store.
 */
class RateLimiter {
  /**
   * @param {object} opts
   * @param {number} opts.windowMs   Rolling window duration in ms
   * @param {number} opts.max        Max events allowed in window
   * @param {number} opts.blockMs    How long to block after exceeding max
   * @param {string} opts.name       Label used in log messages
   */
  constructor({ windowMs, max, blockMs, name }) {
    this.windowMs = windowMs;
    this.max      = max;
    this.blockMs  = blockMs;
    this.name     = name;

    // key → { timestamps: number[], blockedUntil: number }
    this._store = new Map();

    // Prune stale entries every 5 minutes to prevent unbounded growth
    this._pruneInterval = setInterval(() => this._prune(), 300_000);
    if (this._pruneInterval.unref) this._pruneInterval.unref();
  }

  /**
   * hit(key) → { allowed: boolean, remaining: number, retryAfter: number }
   *
   * Call once per event.  Returns whether the event is allowed.
   */
  hit(key) {
    const now   = Date.now();
    let   entry = this._store.get(key);

    if (!entry) {
      entry = { timestamps: [], blockedUntil: 0 };
      this._store.set(key, entry);
    }

    // Check if currently in hard block period
    if (now < entry.blockedUntil) {
      const retryAfter = Math.ceil((entry.blockedUntil - now) / 1000);
      return { allowed: false, remaining: 0, retryAfter };
    }

    // Slide window: drop timestamps older than windowMs
    entry.timestamps = entry.timestamps.filter(t => now - t < this.windowMs);

    if (entry.timestamps.length >= this.max) {
      // Exceeded — enter block period
      entry.blockedUntil = now + this.blockMs;
      entry.timestamps   = [];   // reset so block is clean
      const retryAfter   = Math.ceil(this.blockMs / 1000);
      return { allowed: false, remaining: 0, retryAfter };
    }

    entry.timestamps.push(now);
    const remaining = this.max - entry.timestamps.length;
    return { allowed: true, remaining, retryAfter: 0 };
  }

  /** Check without consuming a slot (for status queries). */
  isBlocked(key) {
    const entry = this._store.get(key);
    if (!entry) return false;
    return Date.now() < entry.blockedUntil;
  }

  /** Explicitly unblock a key (e.g. on socket disconnect). */
  reset(key) {
    this._store.delete(key);
  }

  _prune() {
    const now = Date.now();
    for (const [key, entry] of this._store) {
      if (
        entry.blockedUntil < now &&
        (entry.timestamps.length === 0 ||
          entry.timestamps.every(t => now - t >= this.windowMs))
      ) {
        this._store.delete(key);
      }
    }
  }
}

// ─────────────────────────────────────────────────────────────
//  SECTION 4 — LIMITER INSTANCES
// ─────────────────────────────────────────────────────────────

const httpLimiter = new RateLimiter({
  windowMs: CFG.HTTP_WINDOW_MS,
  max:      CFG.HTTP_MAX,
  blockMs:  CFG.BLOCK_HTTP_MS,
  name:     "http",
});

const connLimiter = new RateLimiter({
  windowMs: CFG.CONN_WINDOW_MS,
  max:      CFG.CONN_MAX,
  blockMs:  CFG.BLOCK_CONN_MS,
  name:     "conn",
});

const joinLimiter = new RateLimiter({
  windowMs: CFG.JOIN_WINDOW_MS,
  max:      CFG.JOIN_MAX,
  blockMs:  CFG.BLOCK_JOIN_MS,
  name:     "join",
});

const signalLimiter = new RateLimiter({
  windowMs: CFG.SIGNAL_WINDOW_MS,
  max:      CFG.SIGNAL_MAX,
  blockMs:  CFG.BLOCK_SIGNAL_MS,
  name:     "signal",
});

// ─────────────────────────────────────────────────────────────
//  SECTION 5 — HTTP MIDDLEWARE
// ─────────────────────────────────────────────────────────────

/**
 * applyHttpMiddleware(app)
 *
 * Mounts a rate-limiting middleware on every HTTP request.
 * Call once after `app` is created, before route registration.
 *
 *   security.applyHttpMiddleware(app);
 */
function applyHttpMiddleware(app) {
  app.use((req, res, next) => {
    // Always pass through socket.io and static assets — no rate limit
    if (req.path.startsWith("/socket.io/")) return next();
    if (/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot|map|webp|avif|json)$/i.test(req.path)) return next();

    const ip     = getIp(req);
    const result = httpLimiter.hit(ip);

    if (!result.allowed) {
      secLog(EventType.HTTP_RATE_LIMIT, ip, {
        path: req.path,
        retryAfter: result.retryAfter,
      });
      res.setHeader("Retry-After", result.retryAfter);
      res.setHeader("X-RateLimit-Limit",     CFG.HTTP_MAX);
      res.setHeader("X-RateLimit-Remaining", 0);
      return res.status(429).json({
        error:   "Too many requests.",
        message: "Too many requests. Please try again later.",
        retryAfter: result.retryAfter,
      });
    }

    res.setHeader("X-RateLimit-Limit",     CFG.HTTP_MAX);
    res.setHeader("X-RateLimit-Remaining", result.remaining);
    next();
  });
}

// ─────────────────────────────────────────────────────────────
//  SECTION 6 — SOCKET CONNECTION GUARD
// ─────────────────────────────────────────────────────────────

/**
 * allowConnection(socket) → boolean
 *
 * Call at the top of io.on("connection", socket => { ... }).
 * Disconnects the socket and returns false if the IP is rate-limited.
 *
 *   io.on("connection", socket => {
 *     if (!security.allowConnection(socket)) return;
 *     // ... rest of your connection handler
 *   });
 */
function allowConnection(socket) {
  const ip     = getIp(socket);
  const result = connLimiter.hit(ip);

  if (!result.allowed) {
    secLog(EventType.CONN_RATE_LIMIT, ip, {
      socketId:   socket.id,
      retryAfter: result.retryAfter,
    });
    socket.emit("security-error", {
      code:    "CONN_RATE_LIMIT",
      message: "Too many connections from your network. Please try again later.",
      retryAfter: result.retryAfter,
    });
    socket.disconnect(true);
    return false;
  }

  return true;
}

// ─────────────────────────────────────────────────────────────
//  SECTION 7 — ROOM JOIN GUARD
// ─────────────────────────────────────────────────────────────

/**
 * allowJoin(socket, roomId) → boolean
 *
 * Validates room ID format and enforces per-IP join rate limit.
 * Call at the top of socket.on("join-room", ...) before any
 * room logic executes.
 *
 *   socket.on("join-room", ({ roomId, deviceName: name }) => {
 *     if (!security.allowJoin(socket, roomId)) return;
 *     // ... existing join logic unchanged
 *   });
 */
function allowJoin(socket, roomId) {
  const ip = getIp(socket);

  // ── 1. Validate room ID format ─────────────────────────────
  if (!roomId || typeof roomId !== "string") {
    secLog(EventType.INVALID_ROOM_ID, ip, { roomId, reason: "missing" });
    socket.emit("join-error", {
      code:    "INVALID_ROOM_ID",
      message: "Invalid room ID.",
    });
    return false;
  }

  const trimmed = roomId.trim();

  if (trimmed.length < CFG.ROOM_ID_MIN || trimmed.length > CFG.ROOM_ID_MAX) {
    secLog(EventType.INVALID_ROOM_ID, ip, {
      roomId:  trimmed,
      reason:  "length",
      len:     trimmed.length,
      min:     CFG.ROOM_ID_MIN,
      max:     CFG.ROOM_ID_MAX,
    });
    socket.emit("join-error", {
      code:    "INVALID_ROOM_ID",
      message: `Room ID must be ${CFG.ROOM_ID_MIN}–${CFG.ROOM_ID_MAX} characters (letters, numbers, - and _ only).`,
    });
    return false;
  }

  if (!CFG.ROOM_ID_REGEX.test(trimmed)) {
    secLog(EventType.INVALID_ROOM_ID, ip, { roomId: trimmed, reason: "chars" });
    socket.emit("join-error", {
      code:    "INVALID_ROOM_ID",
      message: "Room ID may only contain letters, numbers, hyphens and underscores.",
    });
    return false;
  }

  // ── 2. Brute-force / enumeration rate limit ────────────────
  const result = joinLimiter.hit(ip);

  if (!result.allowed) {
    secLog(EventType.JOIN_BRUTE_FORCE, ip, {
      roomId:     trimmed,
      socketId:   socket.id,
      retryAfter: result.retryAfter,
    });
    socket.emit("join-error", {
      code:       "JOIN_RATE_LIMIT",
      message:    "Too many room join attempts. Please slow down.",
      retryAfter: result.retryAfter,
    });
    return false;
  }

  return true;
}

// ─────────────────────────────────────────────────────────────
//  SECTION 8 — SIGNALING SPAM GUARD
// ─────────────────────────────────────────────────────────────

/**
 * allowSignal(socket) → boolean
 *
 * Per-socket signaling rate limiter.  Applies to all five
 * signaling events: file-offer, file-answer, webrtc-offer,
 * webrtc-answer, webrtc-ice.
 *
 * Call at the top of each signaling handler:
 *
 *   socket.on("webrtc-offer", ({ to, sdp }) => {
 *     if (!security.allowSignal(socket)) return;
 *     io.to(to).emit("webrtc-offer", { from: socket.id, sdp });
 *   });
 */
function allowSignal(socket) {
  const key    = socket.id;   // per-socket, not per-IP (already 1 socket/tab)
  const result = signalLimiter.hit(key);

  if (!result.allowed) {
    const ip = getIp(socket);
    secLog(EventType.SIGNAL_SPAM, ip, {
      socketId:   socket.id,
      retryAfter: result.retryAfter,
    });
    socket.emit("security-error", {
      code:       "SIGNAL_RATE_LIMIT",
      message:    "Signaling rate limit exceeded. You have been temporarily blocked.",
      retryAfter: result.retryAfter,
    });
    return false;
  }

  return true;
}

/**
 * cleanupSocket(socketId)
 *
 * Call in socket.on("disconnect") to free limiter memory immediately
 * rather than waiting for the prune interval.
 *
 *   socket.on("disconnect", reason => {
 *     security.cleanupSocket(socket.id);
 *     // ... existing disconnect logic
 *   });
 */
function cleanupSocket(socketId) {
  signalLimiter.reset(socketId);
}

// ─────────────────────────────────────────────────────────────
//  SECTION 9 — TURN CREDENTIAL GUARD
// ─────────────────────────────────────────────────────────────

//  Active TURN tokens: token → { ip, expiresAt, socketId }
const _turnTokens = new Map();

// Prune expired tokens every 2 minutes
const _turnPruneInterval = setInterval(() => {
  const now = Date.now();
  for (const [token, data] of _turnTokens) {
    if (now >= data.expiresAt) {
      _turnTokens.delete(token);
      secLog(EventType.TURN_EXPIRED, data.ip, { token: token.slice(0, 8) + "…" });
    }
  }
}, 120_000);
if (_turnPruneInterval.unref) _turnPruneInterval.unref();

/**
 * generateTurnToken(ip, socketId) → string
 *
 * Creates a short-lived opaque token tied to this IP + socket.
 * Store the token in your /api/ice-config response; clients
 * pass it back as a query param (?token=…) so the server can
 * verify the request is from an active session.
 *
 * NOTE: This is defense-in-depth on top of server-side env
 * credentials.  If you already serve TURN creds only via
 * /api/ice-config (which requires an active session), the
 * tokenization layer is optional but hardens it further.
 */
function generateTurnToken(ip, socketId) {
  const token = _randomHex(24);
  const expiresAt = Date.now() + CFG.TURN_TTL_MS;
  _turnTokens.set(token, { ip, socketId, expiresAt });
  secLog(EventType.TURN_ISSUED, ip, {
    token:     token.slice(0, 8) + "…",
    socketId,
    expiresAt: new Date(expiresAt).toISOString(),
  });
  return token;
}

/**
 * validateTurnToken(token, ip) → boolean
 *
 * Returns true if the token exists, is not expired, and
 * matches the requesting IP.
 */
function validateTurnToken(token, ip) {
  if (!token) return false;
  const data = _turnTokens.get(token);
  if (!data) return false;

  const now = Date.now();
  if (now >= data.expiresAt) {
    _turnTokens.delete(token);
    secLog(EventType.TURN_EXPIRED, ip, { reason: "validated-expired" });
    return false;
  }

  // Bind token to issuing IP to prevent token sharing
  if (data.ip !== ip) {
    secLog(EventType.TURN_REJECTED, ip, {
      reason:    "ip_mismatch",
      issuedTo:  data.ip,
    });
    return false;
  }

  return true;
}

/**
 * iceConfigMiddleware
 *
 * Express middleware for GET /api/ice-config.
 *
 * Strategy A (recommended, zero client changes):
 *   Apply standard HTTP rate limiting already provided by
 *   applyHttpMiddleware().  This middleware additionally checks
 *   an optional ?token= param if TURN token gating is enabled.
 *
 * Strategy B (stricter, requires client to send token):
 *   Emit a turn-token event to the socket after join, then
 *   client appends ?token=<value> to /api/ice-config fetch.
 *
 * For most deployments Strategy A is sufficient — mount this
 * middleware before your existing iceConfig handler:
 *
 *   app.get("/api/ice-config",
 *     security.iceConfigMiddleware,
 *     (req, res) => { res.json({ iceServers }) });
 */
function iceConfigMiddleware(req, res, next) {
  const ip    = getIp(req);
  const token = req.query.token;

  // If a token was provided, validate it
  if (token) {
    if (!validateTurnToken(token, ip)) {
      secLog(EventType.TURN_REJECTED, ip, { reason: "invalid_token" });
      return res.status(403).json({
        error:   "Invalid or expired session token.",
        message: "Please reload the page and try again.",
      });
    }
    // Token valid — consume it (single-use prevents replay)
    _turnTokens.delete(token);
  }

  // If no token is required (default mode), fall through normally.
  // HTTP rate limiting from applyHttpMiddleware() already applies.
  next();
}

// ─────────────────────────────────────────────────────────────
//  SECTION 10 — UTILITY
// ─────────────────────────────────────────────────────────────

function _randomHex(bytes) {
  const arr = new Uint8Array(bytes);
  // Node.js crypto is available in all modern versions
  try {
    require("crypto").randomFillSync(arr);
  } catch {
    for (let i = 0; i < bytes; i++) arr[i] = Math.floor(Math.random() * 256);
  }
  return Array.from(arr).map(b => b.toString(16).padStart(2, "0")).join("");
}

// ─────────────────────────────────────────────────────────────
//  PUBLIC API
// ─────────────────────────────────────────────────────────────

module.exports = {
  // Middleware / guards
  applyHttpMiddleware,
  allowConnection,
  allowJoin,
  allowSignal,
  cleanupSocket,
  iceConfigMiddleware,

  // TURN token helpers (optional stricter mode)
  generateTurnToken,
  validateTurnToken,

  // IP extraction (useful for logging in server.js)
  getIp,

  // Logger (useful to emit custom events from server.js)
  secLog,
  EventType,

  // Expose config for testing / dashboards
  CFG,
};